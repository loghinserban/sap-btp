sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/UIComponent",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast"
], function (Controller, UIComponent, Filter, FilterOperator, JSONModel, MessageToast) {
    "use strict";

    return Controller.extend("companymanagement.controller.Search", {

        onInit: function () {
            this.getView().setModel(new JSONModel({
                results: [],
                busy: false,
                searched: false,
                hasPartial: false
            }), "search");
        },

        onFilterChange: function () {
            clearTimeout(this._iSearchTimer);
            this._iSearchTimer = setTimeout(this.onSearch.bind(this), 300);
        },

        onSearch: function () {
            clearTimeout(this._iSearchTimer);

            var oBundle = this.getView().getModel("i18n").getResourceBundle();
            var oModel = this.getOwnerComponent().getModel();
            var oSearchModel = this.getView().getModel("search");

            var aSelectedItems = this.byId("searchSkills").getSelectedItems();
            var aWantedSkills = [];

            for (var i = 0; i < aSelectedItems.length; i++) {
                aWantedSkills.push({
                    ID: aSelectedItems[i].getKey(),
                    name: aSelectedItems[i].getText()
                });
            }

            var sQuery = this.byId("searchQuery").getValue().trim();

            if (!aWantedSkills.length && !sQuery) {
                oSearchModel.setData({ results: [], busy: false, searched: false, hasPartial: false });
                return;
            }

            var aFilters = [];

            if (aWantedSkills.length) {
                var aSkillFilters = [];

                for (var j = 0; j < aWantedSkills.length; j++) {
                    aSkillFilters.push(new Filter("skill_ID", FilterOperator.EQ, aWantedSkills[j].ID));
                }

                aFilters.push(new Filter({ filters: aSkillFilters, and: false }));
            }

            var iMinRating = parseInt(this.byId("searchMinRating").getSelectedKey(), 10);

            if (iMinRating > 1) {
                aFilters.push(new Filter("rating", FilterOperator.GE, iMinRating));
            }

            oSearchModel.setProperty("/busy", true);

            oModel.read("/EmployeeSkills", {
                filters: aFilters,
                urlParameters: {
                    "$expand": "employee/department,skill"
                },
                success: (oData) => {
                    this._buildResults(oData.results, aWantedSkills);
                    oSearchModel.setProperty("/busy", false);
                    oSearchModel.setProperty("/searched", true);
                },
                error: () => {
                    oSearchModel.setProperty("/results", []);
                    oSearchModel.setProperty("/hasPartial", false);
                    oSearchModel.setProperty("/busy", false);
                    oSearchModel.setProperty("/searched", true);
                    MessageToast.show(oBundle.getText("msgSearchError"));
                }
            });
        },

        _buildResults: function (aRows, aWantedSkills) {
            var oBundle = this.getView().getModel("i18n").getResourceBundle();

            var iMaxMonths = parseInt(this.byId("searchFreshness").getSelectedKey(), 10);
            var sDepartmentId = this.byId("searchDepartment").getSelectedKey();
            var sQuery = this.byId("searchQuery").getValue().trim().toLowerCase();
            var iMinExperience = parseInt(this.byId("searchMinExperience").getValue(), 10);
            var iMinAge = parseInt(this.byId("searchMinAge").getValue(), 10);
            var iMaxAge = parseInt(this.byId("searchMaxAge").getValue(), 10);

            var mByEmployee = {};
            var aResults = [];
            var i;

            for (i = 0; i < aRows.length; i++) {
                var oRow = aRows[i];
                var oEmployee = oRow.employee;

                if (!oEmployee) {
                    continue;
                }

                var iMonths = this.monthsSince(oRow.lastUsed);

                // un skill fara lastUsed nu poate dovedi ca e proaspat
                if (iMaxMonths && (iMonths === null || iMonths > iMaxMonths)) {
                    continue;
                }

                if (sDepartmentId && oEmployee.department_ID !== sDepartmentId) {
                    continue;
                }

                if (sQuery) {
                    var sFullText = (oEmployee.firstName + " " + oEmployee.lastName + " " + oEmployee.email).toLowerCase();

                    if (sFullText.indexOf(sQuery) < 0) {
                        continue;
                    }
                }

                if (!isNaN(iMinExperience) && (oEmployee.experience || 0) < iMinExperience) {
                    continue;
                }

                var iAge = this.calculateAge(oEmployee.dateOfBirth);

                if (!isNaN(iMinAge) && (iAge === null || iAge < iMinAge)) {
                    continue;
                }
                if (!isNaN(iMaxAge) && (iAge === null || iAge > iMaxAge)) {
                    continue;
                }

                var oEntry = mByEmployee[oEmployee.ID];

                if (!oEntry) {
                    oEntry = {
                        ID: oEmployee.ID,
                        fullName: oEmployee.firstName + " " + oEmployee.lastName,
                        email: oEmployee.email,
                        departmentName: oEmployee.department ? oEmployee.department.name : "",
                        experience: oEmployee.experience,
                        age: iAge,
                        skillIds: [],
                        skills: []
                    };

                    mByEmployee[oEmployee.ID] = oEntry;
                    aResults.push(oEntry);
                }

                // acelasi skill de doua ori ar strica acoperirea
                if (oEntry.skillIds.indexOf(oRow.skill_ID) >= 0) {
                    continue;
                }

                var sFreshness = this.formatFreshness(oRow.lastUsed);
                var sSkillName = oRow.skill ? oRow.skill.name : "";

                oEntry.skillIds.push(oRow.skill_ID);
                oEntry.skills.push({
                    label: sSkillName + " · " + oRow.rating + "/5 · " + this._formatAge(iMonths),
                    freshness: sFreshness,
                    icon: this._freshnessIcon(sFreshness),
                    rating: oRow.rating,
                    weight: this._freshnessWeight(sFreshness)
                });
            }

            for (i = 0; i < aResults.length; i++) {
                var oResult = aResults[i];

                oResult.matched = oResult.skills.length;
                oResult.score = this._calculateScore(oResult.skills);
                oResult.worstFreshness = this._worstFreshness(oResult.skills);

                if (!aWantedSkills.length) {
                    oResult.coverageText = oBundle.getText("coverageSkills", [oResult.matched]);
                    continue;
                }

                // aratam si potrivirile partiale, dar spunem ce lipseste
                for (var j = 0; j < aWantedSkills.length; j++) {
                    if (oResult.skillIds.indexOf(aWantedSkills[j].ID) >= 0) {
                        continue;
                    }

                    oResult.skills.push({
                        label: oBundle.getText("skillMissing", [aWantedSkills[j].name]),
                        freshness: "None",
                        icon: "sap-icon://less",
                        rating: 0,
                        weight: 0
                    });
                }

                oResult.coverageText = oBundle.getText("coverage", [oResult.matched, aWantedSkills.length]);
            }

            aResults.sort(function (oLeft, oRight) {
                if (oRight.matched !== oLeft.matched) {
                    return oRight.matched - oLeft.matched;
                }
                if (oRight.score !== oLeft.score) {
                    return oRight.score - oLeft.score;
                }
                return (oRight.experience || 0) - (oLeft.experience || 0);
            });

            var bHasPartial = false;

            if (aWantedSkills.length > 1) {
                for (i = 0; i < aResults.length; i++) {
                    if (aResults[i].matched < aWantedSkills.length) {
                        bHasPartial = true;
                        break;
                    }
                }
            }

            this.getView().getModel("search").setProperty("/results", aResults);
            this.getView().getModel("search").setProperty("/hasPartial", bHasPartial);
        },

        monthsSince: function (sDate) {
            if (!sDate) {
                return null;
            }
            return Math.floor((new Date() - new Date(sDate)) / (1000 * 60 * 60 * 24 * 30.44));
        },

        calculateAge: function (sDateOfBirth) {
            if (!sDateOfBirth) {
                return null;
            }

            var oBirth = new Date(sDateOfBirth);
            var oToday = new Date();
            var iAge = oToday.getFullYear() - oBirth.getFullYear();
            var iMonthDiff = oToday.getMonth() - oBirth.getMonth();

            if (iMonthDiff < 0 || (iMonthDiff === 0 && oToday.getDate() < oBirth.getDate())) {
                iAge = iAge - 1;
            }

            return iAge;
        },

        // verde sub 1 an, galben 1-2 ani, rosu peste 2
        formatFreshness: function (sLastUsed) {
            var iMonths = this.monthsSince(sLastUsed);

            if (iMonths === null) {
                return "None";
            }
            if (iMonths <= 12) {
                return "Success";
            }
            if (iMonths <= 24) {
                return "Warning";
            }
            return "Error";
        },

        _freshnessWeight: function (sFreshness) {
            if (sFreshness === "Success") {
                return 1;
            }
            if (sFreshness === "Warning") {
                return 0.7;
            }
            if (sFreshness === "Error") {
                return 0.4;
            }
            return 0.5;
        },

        _freshnessIcon: function (sFreshness) {
            if (sFreshness === "Success") {
                return "sap-icon://message-success";
            }
            if (sFreshness === "Warning") {
                return "sap-icon://message-warning";
            }
            if (sFreshness === "Error") {
                return "sap-icon://message-error";
            }
            return "sap-icon://question-mark";
        },

        _formatAge: function (iMonths) {
            var oBundle = this.getView().getModel("i18n").getResourceBundle();

            if (iMonths === null) {
                return oBundle.getText("neverUsed");
            }
            if (iMonths < 1) {
                return oBundle.getText("usedThisMonth");
            }
            if (iMonths < 12) {
                return oBundle.getText("usedMonthsAgo", [iMonths]);
            }
            return oBundle.getText("usedYearsAgo", [Math.floor(iMonths / 12)]);
        },

        _calculateScore: function (aSkills) {
            if (!aSkills.length) {
                return 0;
            }

            var fTotal = 0;

            for (var i = 0; i < aSkills.length; i++) {
                fTotal = fTotal + aSkills[i].rating * aSkills[i].weight;
            }

            return Math.round((fTotal / aSkills.length / 5) * 100);
        },

        _worstFreshness: function (aSkills) {
            var aOrder = ["Success", "None", "Warning", "Error"];
            var sWorst = "Success";

            for (var i = 0; i < aSkills.length; i++) {
                if (aOrder.indexOf(aSkills[i].freshness) > aOrder.indexOf(sWorst)) {
                    sWorst = aSkills[i].freshness;
                }
            }

            return sWorst;
        },

        onClearFilters: function () {
            this.byId("searchSkills").setSelectedKeys([]);
            this.byId("searchMinRating").setSelectedKey("1");
            this.byId("searchFreshness").setSelectedKey("0");
            this.byId("searchDepartment").setSelectedKey("");
            this.byId("searchMinExperience").setValue("");
            this.byId("searchMinAge").setValue("");
            this.byId("searchMaxAge").setValue("");
            this.byId("searchQuery").setValue("");

            this.getView().getModel("search").setData({
                results: [],
                busy: false,
                searched: false,
                hasPartial: false
            });
        },

        onResultPress: function (oEvent) {
            var oItem = oEvent.getParameter("listItem");
            var oContext = oItem.getBindingContext("search");

            if (!oContext) {
                return;
            }
            oEvent.getSource().removeSelections(true);

            UIComponent.getRouterFor(this).navTo("RouteDetail", { param: oContext.getProperty("ID") });
        },

        onNavBack: function () {
            UIComponent.getRouterFor(this).navTo("RouteView", {}, true);
        }

    });
});
