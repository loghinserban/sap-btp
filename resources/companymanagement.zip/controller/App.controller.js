sap.ui.define(["sap/ui/core/mvc/Controller"],e=>{"use strict";return e.extend("companymanagement.controller.App",{})});
//# sourceMappingURL=App.controller.js.map